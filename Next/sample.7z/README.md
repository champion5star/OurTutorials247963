# next_with_redux
Attemp connect redux to next.js 
Theme Provider will define in MaterialUI -> styles => advancde => next.js
https://material-ui.com/styles/advanced/#next-js
